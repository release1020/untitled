create
    definer = root@localhost function f_hello() returns varchar(100)
BEGIN
	RETURN 'Hello World';
END;

