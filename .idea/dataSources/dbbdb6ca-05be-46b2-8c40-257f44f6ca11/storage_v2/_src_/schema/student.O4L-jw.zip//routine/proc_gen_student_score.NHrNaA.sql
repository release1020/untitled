create
    definer = root@localhost procedure proc_gen_student_score(IN lessionid int)
BEGIN
	DECLARE endLoop int DEFAULT 0;
	DECLARE tmp_id int;
	DECLARE tmp_score DECIMAL(10,2);
	DECLARE cur CURSOR FOR SELECT id,score from t_student_score where lession_id = lessionid;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET endLoop = 1;

	OPEN cur;
	FETCH cur into tmp_id,tmp_score;
	WHILE endLoop < 1 DO
	IF tmp_score >= 90 THEN update t_student_score set level = 'A' where id = tmp_id;
	ELSEIF tmp_score >= 80 THEN update t_student_score set level = 'B' where id = tmp_id;
	ELSEIF tmp_score >= 70 THEN update t_student_score set level = 'C' where id = tmp_id;
	ELSE UPDATE t_student_score set level = 'D' where id = tmp_id;
	END IF;

	FETCH cur into tmp_id,tmp_score;


	END WHILE;

	CLOSE cur;

END;

