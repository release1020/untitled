create
    definer = root@localhost function f_sum_unil(arg0 int) returns int
BEGIN
	DECLARE sum INT DEFAULT 0;
	DECLARE i INT DEFAULT 0;

	WHILE i <= 100 DO
	SET sum = sum + i;
	SET i = i + 1;
	END WHILE;


	RETURN sum;
END;

