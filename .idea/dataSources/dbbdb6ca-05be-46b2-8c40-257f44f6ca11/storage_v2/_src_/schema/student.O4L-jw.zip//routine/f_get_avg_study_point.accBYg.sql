create
    definer = root@localhost function f_get_avg_study_point(classid int) returns float
BEGIN
		DECLARE endLoop INT DEFAULT 0;
		DECLARE point int DEFAULT 0; -- 学分临时变量
		DECLARE sum int DEFAULT 0; -- 总学分数
		DECLARE amount int; -- 总学生数

		DECLARE cur CURSOR FOR SELECT study_points from t_students where class_id = classid;
		DECLARE CONTINUE HANDLER FOR NOT FOUND set endLoop = 1;
		

		OPEN cur;
		FETCH cur INTO point;
		WHILE endLoop < 1 do 
			SET sum = sum + point;
			FETCH cur INTO point;
		END WHILE;

		CLOSE cur;

		SELECT count(*) INTO amount from t_students where class_id = classid;

		RETURN ROUND(sum/amount,2); -- 很奇怪，函数不能直接四舍五入返回2位小数
END;

